# Personal Site + Blog (GitHub Pages, Jekyll Minima)

1) Create a **public** repo named `<your-username>.github.io` on GitHub.
2) Upload all files in this folder to the repo root and commit to `main`.
3) Visit `https://<your-username>.github.io` after ~1 minute.

To write a new post, add a Markdown file to `_posts/` with the name `YYYY-MM-DD-your-title.md`
and this front matter:

```
---
layout: post
title: "<Post Title>"
categories: research
tags: [graphs, finance, experiments]
---
```
