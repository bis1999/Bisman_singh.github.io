---
layout: home
title: Home
---

Welcome! I write about **network science**, **link prediction**, **quant research**, and **optimization**.

- Latest posts are below.
- See the [About](/about) page for who I am, and the [Blog](/blog) page for all posts.
