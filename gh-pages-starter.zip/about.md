---
layout: page
title: About
permalink: /about/
---

Hi! I'm **Bisman Singh**—Applied Math (CU Boulder), BI/quant-curious, and the builder of **linkpredx**.
I publish notes and research-in-progress here. Connect on [GitHub](https://github.com/<your-username>) or [LinkedIn](https://www.linkedin.com/in/siddharth101/).
